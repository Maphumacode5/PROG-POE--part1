import javax.swing.JOptionPane;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class MessageSystem {
    private final List<String> sentMessages = new ArrayList<>();
    private final List<String> storedMessages = new ArrayList<>();
    private final List<String> disregardedMessages = new ArrayList<>();
    private final List<String> messageHashes = new ArrayList<>();
    private final List<String> messageIDs = new ArrayList<>();
    private int messageCounter = 1;

    public void startMessaging(String userPhone) {
        int messageLimit = Integer.parseInt(JOptionPane.showInputDialog("How many messages do you want to send?"));

        while (messageCounter <= messageLimit) {
            String[] options = {
                "Send Message", 
                "View Sent Messages", 
                "View Stored Messages", 
                "View Disregarded Messages", 
                "Quit"
            };
            int choice = JOptionPane.showOptionDialog(null,
                "QuickChat Menu\nMessages sent: " + sentMessages.size(),
                "Main Menu",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                options,
                options[0]);

            switch (choice) {
                case 0 -> sendMessage(userPhone);
                case 1 -> showSentMessages();
                case 2 -> showStoredMessages();
                case 3 -> showDisregardedMessages();
                case 4 -> { return; }
                default -> {}
            }
        }
    }

    private void sendMessage(String senderPhone) {
        String recipient;
        while (true) {
            recipient = JOptionPane.showInputDialog("Recipient phone (+27xxxxxxxxx):");
            if (recipient != null && recipient.matches("^\\+27\\d{9}$")) break;
            JOptionPane.showMessageDialog(null, "Invalid format! Must be +27xxxxxxxxx");
        }

        String message = JOptionPane.showInputDialog("Enter your message (max 250 characters):");
        if (message == null) return;

        if (message.length() > 250) {
            JOptionPane.showMessageDialog(null, "Message too long by " + (message.length() - 250) + " characters.");
            return;
        }

        String messageID = generateMessageID();
        String hash = generateMessageHash(messageID, message);

        String[] actions = {"Send", "Disregard", "Store"};
        int action = JOptionPane.showOptionDialog(null,
            "Choose an action for this message:",
            "Message Options",
            JOptionPane.DEFAULT_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            actions,
            actions[0]);

        switch (action) {
            case 0 -> {
                sentMessages.add(message);
                messageHashes.add(hash);
                messageIDs.add(messageID);
                JOptionPane.showMessageDialog(null, "Message sent.\nID: " + messageID + "\nHash: " + hash);
                messageCounter++;
            }
            case 1 -> {
                disregardedMessages.add(message);
                JOptionPane.showMessageDialog(null, "Message disregarded.");
                messageCounter++;
            }
            case 2 -> {
                storeMessageJSON(messageID, recipient, message);
                storedMessages.add(message);
                JOptionPane.showMessageDialog(null, "Message stored.");
                messageCounter++;
            }
        }
    }

    private String generateMessageID() {
        return String.valueOf(System.currentTimeMillis() + new Random().nextInt(999));
    }

    private String generateMessageHash(String id, String message) {
        String[] words = message.split(" ");
        String first = words.length > 0 ? words[0] : "";
        String last = words.length > 1 ? words[words.length - 1] : first;
        return (id.substring(0, 2) + ":" + first + last).toUpperCase();
    }

    private void storeMessageJSON(String id, String recipient, String message) {
        JSONParser parser = new JSONParser();
        JSONArray messagesArray = new JSONArray();

        try (FileReader reader = new FileReader("stored_messages.json")) {
            Object obj = parser.parse(reader);
            messagesArray = (JSONArray) obj;
        } catch (Exception e) {
            // file doesn't exist or is empty – will be created
        }

        JSONObject msgObj = new JSONObject();
        msgObj.put("id", id);
        msgObj.put("recipient", recipient);
        msgObj.put("message", message);
        messagesArray.add(msgObj);

        try (FileWriter file = new FileWriter("stored_messages.json")) {
            file.write(messagesArray.toJSONString());
            file.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void showSentMessages() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < sentMessages.size(); i++) {
            sb.append("- Message ").append(i + 1).append(" -\n");
            sb.append("  • ID: ").append(messageIDs.get(i)).append("\n");
            sb.append("  • Hash: ").append(messageHashes.get(i)).append("\n");
            sb.append("  • Content: ").append(sentMessages.get(i)).append("\n\n");
        }

        JOptionPane.showMessageDialog(null, sb.length() > 0 ? sb.toString() : "No messages sent yet.");
    }

    private void showStoredMessages() {
        JSONParser parser = new JSONParser();
        StringBuilder sb = new StringBuilder();

        try (FileReader reader = new FileReader("stored_messages.json")) {
            JSONArray messagesArray = (JSONArray) parser.parse(reader);
            int count = 1;
            for (Object obj : messagesArray) {
                JSONObject msg = (JSONObject) obj;
                sb.append("- Stored Message ").append(count++).append(" -\n");
                sb.append("  • ID: ").append(msg.get("id")).append("\n");
                sb.append("  • Recipient: ").append(msg.get("recipient")).append("\n");
                sb.append("  • Content: ").append(msg.get("message")).append("\n\n");
            }
        } catch (Exception e) {
            sb.append("No stored messages found.");
        }

        JOptionPane.showMessageDialog(null, sb.toString());
    }

    private void showDisregardedMessages() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < disregardedMessages.size(); i++) {
            sb.append("- Disregarded Message ").append(i + 1).append(" -\n");
            sb.append("  • Content: ").append(disregardedMessages.get(i)).append("\n\n");
        }

        JOptionPane.showMessageDialog(null, sb.length() > 0 ? sb.toString() : "No disregarded messages.");
    }
}
