public class ChatApp {
    public static void main(String[] args) {
        // Part 1: Authentication
        login auth = new login();
        auth.registerUser();
        
        if(auth.loginUser()) {
            // Part 2: Messaging
            MessageSystem msgSystem = new MessageSystem();
            msgSystem.startMessaging(auth.getPhoneNumber());
        }
    }
}