import javax.swing.JOptionPane;

public class login {
    private String username;
    private String password;
    private String phoneNumber;

    // Method to register a new user with input validation
    public void registerUser() {
        // Validate username: must contain "_" and be 5 characters or fewer
        while(true) {
            String input = JOptionPane.showInputDialog("Create username (must contain '_' and be ≤5 chars):");
            if(input.contains("_") && input.length() <= 5) {
                this.username = input;
                break;
            }
            JOptionPane.showMessageDialog(null, "Invalid! Must contain '_' and be ≤5 characters");
        }

        // Validate password: at least 8 characters, includes 1 capital letter, 1 number, and 1 special character
        while(true) {
            String input = JOptionPane.showInputDialog("Create password (8+ chars, 1 capital, 1 number, 1 special char):");
            if(input.matches("^(?=.*[A-Z])(?=.*\\d)(?=.*[!@#$%^&*]).{8,}$")) {
                this.password = input;
                break;
            }
            JOptionPane.showMessageDialog(null, "Password must contain:\n- 8+ characters\n- 1 capital letter\n- 1 number\n- 1 special character");
        }

        // Validate phone number: must follow South African format +27 followed by 9 digits
        while(true) {
            String input = JOptionPane.showInputDialog("Enter SA phone (+27xxxxxxxxx):");
            if(input.matches("^\\+27\\d{9}$")) {
                this.phoneNumber = input;
                break;
            }
            JOptionPane.showMessageDialog(null, "Invalid! Must be +27 followed by 9 digits");
        }
        
        // Show success message after all fields are correctly validated
        JOptionPane.showMessageDialog(null, "Registration successful!");
    }

    // Method to authenticate a user login
    public boolean loginUser() {
        int attempts = 3; // Allow up to 3 login attempts

        while(attempts > 0) {
            String userInput = JOptionPane.showInputDialog("Enter username:");
            String passInput = JOptionPane.showInputDialog("Enter password:");
            
            // Check if input matches the stored username and password
            if(userInput.equals(username) && passInput.equals(password)) {
                JOptionPane.showMessageDialog(null, "Welcome back, " + username + "!");
                return true; // Login successful
            }

            attempts--; // Decrease attempt count on failure
            JOptionPane.showMessageDialog(null, "Invalid! Attempts left: " + attempts);
        }

        // Lock user out after 3 failed attempts
        JOptionPane.showMessageDialog(null, "Too many failed attempts!");
        return false; // Login failed
    }

    // Getter method to access the user's phone number
    public String getPhoneNumber() {
        return this.phoneNumber;
    }
}
