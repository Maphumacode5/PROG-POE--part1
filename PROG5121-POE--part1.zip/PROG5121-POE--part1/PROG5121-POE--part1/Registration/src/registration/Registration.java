
package registration;

import java.util.Scanner;

 
        
public class Registration {

    
    public static void main(String[] args) { 
    {
        Scanner scanner = new Scanner(System.in);{
        
        // Arrays to store [username, passwords, cellphone]
        String[] userAccount = new String[3];
        
        // Get username
        System.out.print("enter your username:");
        userAccount[0]= scanner.nextLine();
        
        //Get password
        System.out.print("Enter your password:");
        userAccount[1] = scanner.nextLine();
        
        // Get and validate South African cellphone number
        
        String cellphone;
        while (true){
            System.out.print("Enter your South African cellphone number e.g 0712548229:");
            cellphone = scanner.nextLine();
            
            if (!cellphone.matches("0[6-8][0-9]")){
                System.out.println("invalid cellphone number.It must start with 07, 06 or 08 and be 10 digits");
                
                
                // display account info
                System.out.println("Account created successuflly ohh temm!");
                System.out.println("username:" +userAccount [0]);
                System.out.println("cellphne:"+ userAccount[2]);
                
                scanner.close();
            }else{
                userAccount[2] =  cellphone;
                break;
            }
    }
        }
}       

    

        
        }
    }
