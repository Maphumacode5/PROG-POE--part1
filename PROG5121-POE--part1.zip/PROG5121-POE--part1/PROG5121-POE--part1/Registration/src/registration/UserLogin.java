
package registration;

import java.util.Scanner;


public class UserLogin 
{
  Scanner scanner = new Scanner(System.in);

    // sample registration data
    String registrationUsername = "testuser";
    String registrationPassword = "pas123";{

    //Login prompt
    System.out.print("Enter username:");
    String username = scanner.nextLine();

    System.out.print ("Enter password:");
    String password = scanner.nextLine();

    // check credentails
    if (username.equals(registrationUsername)&& password.equal(registerpassword))
    {
        System.out.println("Login successful. welcome ohh tem" + username + "!");
    }else{
        System.out.println("invalid username or password");

    }

    scanner.close();
    }   
}