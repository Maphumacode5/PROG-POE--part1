package prop.poe.part.pkg1;

public class PROPPOEPart1 
{

    public static void main(String[] args) 
    {
        
    }
    
}
